﻿namespace SilentReverbMod
{
    //Place holder
    public class PassiveAbility_SilentReverb1 : PassiveAbilityBase
    {
    }
}
