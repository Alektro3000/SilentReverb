﻿namespace SilentReverbMod
{
    // Token: 0x02000027 RID: 39
    public class DiceCardSelfAbility_SiRvVivace : DiceCardSelfAbility_SiRvEgo
    {
        // Token: 0x06000087 RID: 135 RVA: 0x00002493 File Offset: 0x00000693
        public override ResonanceEffect GetType()
        {
            return ResonanceEffect.CloseResonance;
        }
    }
}
