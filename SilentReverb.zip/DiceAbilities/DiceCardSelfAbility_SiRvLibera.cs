﻿namespace SilentReverbMod
{
    // Token: 0x02000028 RID: 40
    public class DiceCardSelfAbility_SiRvLibera : DiceCardSelfAbility_SiRvEgo
    {
        // Token: 0x0600008A RID: 138 RVA: 0x00002496 File Offset: 0x00000696
        public override ResonanceEffect GetType()
        {
            return ResonanceEffect.DistantResonance;
        }
    }
}
