﻿namespace SilentReverbMod
{
    // Token: 0x02000061 RID: 97
    public class DiceCardAbility_SiRvCreschendoBoss1 : DiceCardAbility_SiRvSilentReverbBase
    {
    }
}
