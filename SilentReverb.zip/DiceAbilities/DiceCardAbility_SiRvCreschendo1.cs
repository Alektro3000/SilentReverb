﻿namespace SilentReverbMod
{
    // Token: 0x02000030 RID: 48
    public class DiceCardAbility_SiRvCreschendo1 : DiceCardAbility_SiRvSilentReverbBase
    {
    }
}
