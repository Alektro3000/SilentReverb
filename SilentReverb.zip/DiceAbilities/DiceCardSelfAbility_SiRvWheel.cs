﻿namespace SilentReverbMod
{
    // Token: 0x02000020 RID: 32
    public class DiceCardSelfAbility_SiRvWheel : DiceCardSelfAbility_SiRvBase
    {
    }
}
