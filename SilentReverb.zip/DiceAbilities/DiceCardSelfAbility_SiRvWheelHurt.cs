﻿namespace SilentReverbMod
{
    // Token: 0x02000086 RID: 134
    public class DiceCardSelfAbility_SiRvWheelHurt
    {
    }
}
