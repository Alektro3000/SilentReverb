﻿namespace System.Runtime.CompilerServices
{
    // Token: 0x02000069 RID: 105
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
    internal sealed class IgnoresAccessChecksToAttribute : Attribute
    {
        // Token: 0x06000191 RID: 401 RVA: 0x00002D32 File Offset: 0x00000F32
        internal IgnoresAccessChecksToAttribute(string assemblyName)
        {
        }
    }
}
